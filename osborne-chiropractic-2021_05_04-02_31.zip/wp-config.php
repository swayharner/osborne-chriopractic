<?php
define('WP_AUTO_UPDATE_CORE', 'minor');
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'demo509_wp94' );

/** MySQL database username */
define( 'DB_USER', 'demo509_wp94' );

/** MySQL database password */
define( 'DB_PASSWORD', '9.S9cfa@4p' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'ecwtj6pznybnuyncvrhq6kwail0bi3xpafxetaan47cqxeqgayoabdm4k7bdvg4v' );
define( 'SECURE_AUTH_KEY',  '8zhoeui2rlj7fyl3kos6ttooz2fpbj7u9lkjrhmrxjo6qic0i2ptdj324faxhxnn' );
define( 'LOGGED_IN_KEY',    'zf4jugjnsf2wstfizgmbe3nl2bqnxulrrponyhlbiruhz7ulixqp9ews5p1d9psl' );
define( 'NONCE_KEY',        '4j2hxd1x1ba2bdz6aomb1hvf9tj5pru0uzmeqoglukjpxxb7wyrhnfteazh4zfd2' );
define( 'AUTH_SALT',        'phfhafwhm1slrlb9x4b2myom69qidhcyn0547imqwfetv4fbnbt44qfqhyppqpun' );
define( 'SECURE_AUTH_SALT', 'fkt2afidfmqqahisc3t0mrmrh3pdz7rvssbktgnqbd0amttreabbjzy5n5symrth' );
define( 'LOGGED_IN_SALT',   'uqswenms7rrfnoyi4pyugimjrn78azqhq3r4yynjstyug2g5dklcis9oc5dwzink' );
define( 'NONCE_SALT',       'md3begtmdvrplyi3jusywqxvzxdadkkwep4ajh90h5nhh35rcr3ohggsb7btllxr' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wpg2ks_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
